# Handoff: Cyberpunk City Portfolio (Vaibhav Singh)

## Overview
A single-page personal portfolio. The whole viewport is a painted neon cyberpunk cityscape (`assets/city.png`). Five labels baked into the image — 01 ABOUT, 02 PROJECTS, 03 EXPERIENCE, 04 SKILLS, 05 CONTACT — are clickable hotspots. Clicking one zooms the camera into that point of the city, then a translucent holographic panel reveals that section's content. The scene is kept alive with subtle canvas effects (twinkling stars, glowing/flickering city lights, pulsing sign glows) and a mouse parallax.

## About the Design Files
`reference/Portfolio.dc.html` is a **design reference built in HTML** — a working prototype of the intended look and behavior, not production code. Recreate it in the target codebase's stack. If no codebase exists, a good fit is **Vite + React + TypeScript** (or Next.js static export), plain CSS modules or Tailwind, and a single `<canvas>` for effects. No backend needed; deploy to Vercel/Netlify/GitHub Pages.

To view the reference: serve the `reference/` folder (`npx serve reference`) and open `Portfolio.dc.html`. It uses a small runtime (`support.js`); ignore that runtime — all styling is inline in the template and all behavior is in the `class Component` at the bottom of the file.

## Fidelity
**High-fidelity.** Colors, type, copy, timings and effect parameters below are final. Hotspot coordinates are tuned to this exact image.

---

## Screens / Views

### 1. City (idle state)
**Layout**
- Root: `position:fixed; inset:0; overflow:hidden; background:#05060f`. Body `overflow:hidden`.
- **Scene container** keeps the image's 1448×1086 aspect and *covers* the viewport, centered:
  `width:max(100vw, calc(100vh*1448/1086)); height:max(100vh, calc(100vw*1086/1448)); left:50%; top:50%; transform:translate(-50%,-50%)`.
  Everything positioned in % inside it (hotspots, glows, canvas) stays locked to the image.
- Layer order inside scene: parallax wrapper → zoom wrapper → `<img>` → sign-glow divs → `<canvas>` (full size, pointer-events none) → hotspot buttons.
- Screen-space overlays above scene: optional scanlines, vignette `radial-gradient(ellipse at center, transparent 55%, rgba(3,3,12,.75) 100%)`, accent flash layer (`mix-blend-mode:screen`).

**Hotspots** (invisible buttons over the baked-in labels; % of scene box)
| id | label | left | top | width | height | zoom origin (x% y%) | color | kana | icon (Lucide) |
|---|---|---|---|---|---|---|---|---|---|
| about | ABOUT | 27.6 | 21.3 | 8.3 | 3.4 | 32.8 27.6 | #5ff3ff | 自己紹介 | user |
| projects | PROJECTS | 19.9 | 40.0 | 10.2 | 3.4 | 28.4 46.8 | #ff4fb8 | プロジェクト | box |
| experience | EXPERIENCE | 53.7 | 10.9 | 9.8 | 3.2 | 54.9 17.3 | #5ff3ff | 経験 | briefcase |
| skills | SKILLS | 73.6 | 42.6 | 8.7 | 3.4 | 75.5 49.3 | #ff4fb8 | 技術 | terminal |
| contact | CONTACT | 83.5 | 15.8 | 9.8 | 3.4 | 89.2 22.6 | #ffc46b | 連絡 | mail |

- Default: transparent bg, `1.5px solid transparent`, radius 4px.
- Hover/focus: `border-color:<color>; box-shadow:0 0 18px 2px <color>, inset 0 0 14px <color>; background:rgba(255,255,255,.06)`; transition 200ms.
- Hidden (opacity 0, pointer-events none) whenever a panel is open/opening.

**HUD (bottom-left, `left:28px; right:28px; bottom:24px`, column, gap 10px)** — fades out (400ms) when a panel opens.
- Name: "VAIBHAV SINGH" — Chakra Petch 700, `clamp(22px,3vw,38px)`, letter-spacing .08em, #fff, `text-shadow:0 0 12px rgba(95,243,255,.7), 2px 0 0 rgba(255,79,184,.6)`.
- Subtitle: "BACKEND ENGINEER // NOIDA, IN" — JetBrains Mono 12px, ls .22em, #5ff3ff. 8px gap below.
- "SELECT A NODE _" — 11px, ls .2em, #8b93b8; the "_" is #5ff3ff and blinks (1s steps(1)).
- Nav row (flex-wrap, gap 8px) of 5 buttons, a fallback for small screens where labels crop off: JetBrains Mono 12px ls .08em #d9e2ff, bg rgba(6,8,22,.75), `1px solid rgba(255,255,255,.18)`, padding 8px 12px, radius 4px, backdrop-blur 6px; Lucide icon 14px in section color + "01." in section color + label. Hover: border + `box-shadow:0 0 12px <color>`, text #fff.
- Note: the HUD originally sat top-left but collided with the ABOUT label on short/wide viewports — keep it bottom-left.

### 2. Section panel (open state)
Centered overlay (`inset:0; flex center; padding:20px`). Clicking the backdrop closes; clicks inside don't propagate.

**Panel shell**
- `max-width:940px; width:100%; max-height:84vh`; flex column.
- Background `linear-gradient(180deg, rgba(12,14,36,.62), rgba(6,7,20,.8))`, `backdrop-filter:blur(14px) saturate(1.4)`.
- Border `1px solid <accent>99` (accent at ~60% alpha), radius 6px.
- Shadow `0 0 0 1px rgba(0,0,0,.4), 0 0 40px <accent>55, inset 0 1px 0 rgba(255,255,255,.08)`.
- Four corner brackets: 14×14px, 2px accent borders on the two outer sides, inset 6px from each corner.

**Header** (padding 22px 28px 18px; space-between)
- Left: label chip mirroring the in-image labels — padding 8px 14px, `1px solid <accent>`, radius 4px, bg rgba(6,8,20,.75), `box-shadow:0 0 14px <accent>55, inset 0 0 10px <accent>55`, 13px ls .08em: Lucide icon 16px (stroke accent, width 2) + "02." (accent) + "PROJECTS" (#fff, 500).
- Next to it: kana (e.g. プロジェクト) 14px, ls .3em, accent, opacity .75, `text-shadow:0 0 10px <accent>`, nowrap.
- Right: close button "ESC CLOSE" ("ESC" in #8b93b8) — 12px ls .12em, bg rgba(6,8,20,.6), `1px solid rgba(255,255,255,.2)`, padding 8px 12px, radius 4px, nowrap. Hover: accent border + glow.
- Under header: 1px divider, margin 0 28px, `linear-gradient(90deg, <accent>, transparent 70%)`, opacity .6.

**Body**: scrollable (`overflow-y:auto; overflow-x:hidden`), padding 24px 28px 28px, column gap 22px. Thin scrollbar: 6px, thumb rgba(255,255,255,.18) radius 3px, transparent track.

**Footer nav**: padding 14px 28px 20px, top border rgba(255,255,255,.06), flex-wrap gap 8px. Buttons `flex:none`, nowrap: 11px ls .08em, bg rgba(6,8,20,.6), radius 4px, padding 7px 11px, icon 13px in section color + "01. ABOUT". Active section: text + border in its color; others: text #8b93b8, border rgba(255,255,255,.15). Hover: #fff + color border + glow.

**Shared content styles**
- Display headings: Chakra Petch 600–700, #fff, glow `text-shadow:0 0 22px <accent at .4>`. Section h2 `clamp(28px,4vw,44px)` lh 1.05; project h3 24px (pink glow rgba(255,79,184,.45)).
- Body: JetBrains Mono 14–15px, lh 1.6–1.7, #c4cdf0. Small labels: 11px ls .18em in accent.
- Glass card: radius 6px, `1px solid <color at .25–.3>`, bg `linear-gradient(135deg, <color at .08>, <color at .02>)`, padding 18px 20px.
- Chip/tag: 12px, `1px solid rgba(95,243,255,.25)`, radius 4px, bg rgba(6,8,20,.5), padding 6px 10px.
- Links: #5ff3ff, hover #ff4fb8, no underline. External links open in a new tab (`↗` prefix).

### Section content (exact copy)

**01 ABOUT** (cyan)
- H2: "I build the backend that keeps the numbers right."
- P: "Computer Science student at Jaypee Institute of Information Technology, most recently a backend intern at Drona Infotech, where I shipped billing, auth and HR systems on FastAPI and PostgreSQL. I came up through machine learning — one IEEE publication, a few fine-tuned models — and now spend most of my time on APIs, schemas and access control."
- Two cards (auto-fit grid, min 200px): EDUCATION — "B.Tech, Computer Science & Engineering" / "JIIT Noida · Aug 2023 – May 2027"; CGPA — "7.11 / 10.0".
- COURSEWORK chips: Data Structures & Algorithms, Object-Oriented Programming, Operating Systems, DBMS, Computer Networks, Machine Learning.

**02 PROJECTS** (pink) — one pink glass card each: title + date (12px #8b93b8, right), stack line (12px #ff8fd0), bullet list, links.
1. **Academic Digital Twin** — MAY 2026 — FastAPI · PostgreSQL · Docker · Scikit-Learn
   - Three-tier system — Vercel frontend, containerized FastAPI on Render, Supabase PostgreSQL — serving 18 REST endpoints for auth, logging, analytics, simulation and PDF export.
   - What-if engine rescores performance and stress on any change to study hours, sleep or workload, cutting feedback from weeks to under a second.
   - Random Forest and clustering models return burnout, performance and goal-alignment predictions in under 1s from 5 daily inputs.
   - Links: LIVE https://minor2-digital-twin.vercel.app/ · GITHUB https://github.com/Vaibhav1962/minor2-digital-twin
2. **Soul — Emotion & Mental Health Platform** — FEB 2025 — PyTorch · Transformers · Docker
   - Fine-tuned RoBERTa-base on 43K GoEmotions samples: 93% accuracy across 28 emotion classes, 0.928 F1 on crisis detection.
   - Model and tokenizer load once at startup instead of per request, cutting latency for concurrent users.
   - Each emotion maps to a clinical risk level; alerts fire whenever a score crosses threshold — no silent misses.
3. **Plant Disease Classifier** — JUN 2024 — TensorFlow · Keras · Docker
   - 93.9% test accuracy across 38 classes and 14 crops, fine-tuning MobileNetV2 on PlantVillage with selective layer unfreezing.
   - 13 MB model that runs on low-power devices, trained on 224×224 images with rotation, flip and zoom augmentation.
   - Links: LIVE https://vaibhav-23103370.streamlit.app/ · GITHUB https://github.com/Vaibhav1962/plant-disease-classifier
4. Cyan card — "RESEARCH PUBLICATION · IEEE CICN 2024" — **Smart Retail: ML for Demand Prediction, Pricing and Inventory Management** (20px)
   - Random Forest pipeline on competitor pricing, customer preference and seasonal features: 8.15% MSE on demand, 1.11% on price across 10 products.
   - Presented at the 16th International Conference, Indore; 4 citations, 532 full-text views.
   - Link: DOI 10.1109/CICN63059.2024.10847534 → https://doi.org/10.1109/CICN63059.2024.10847534

**03 EXPERIENCE** (cyan)
- H2 "Drona Infotech" (`clamp(26px,3.6vw,38px)`), sub "Software Engineer Intern (Backend) · Noida" (14px #5ff3ff); date pill right: "JUN 2026 — JUL 2026".
- Four rows, each a cyan glass card, grid `44px 1fr`, index "[01]"…"[04]" in #5ff3ff, bold lead in #fff:
  1. **Billing module.** Stores each client's agreed fee and recomputes the outstanding balance whenever staff log a payment — a running view of revenue owed vs. collected.
  2. **RBAC on a live HR platform.** Role-based access control in FastAPI for 3 user types — bcrypt-hashed passwords, each role bound to a signed JWT.
  3. **Attendance & client management.** Normalized PostgreSQL schema via SQLAlchemy ORM tracking check-ins and each client from onboarding to delivery.
  4. **Docker.** Containerized the service and its dependencies so it runs the same on every teammate's machine.

**04 SKILLS** (pink)
- Prompt line "$ cat ./stack.txt" (13px #8b93b8).
- Four pink cards (auto-fit, min 240px), label 11px #ff4fb8, value 14px lh 1.8 #fff:
  BACKEND — FastAPI · REST API design · JWT auth · RBAC · SQLAlchemy ORM · PostgreSQL · MySQL
  LANGUAGES — Python · C++ · SQL
  INFRASTRUCTURE & TOOLS — Docker · Git · Render · Vercel · Supabase
  MACHINE LEARNING — PyTorch · TensorFlow · Scikit-Learn · Pandas · NumPy

**05 CONTACT** (amber #ffc46b)
- H2 "Open a channel." (amber glow).
- List of rows (grid `110px 1fr`, padding 14px 0, bottom border rgba(255,255,255,.1)); label 12px ls .16em #ffc46b, value 15px #fff, hover value → #ffc46b:
  EMAIL vaibhav.singh.252005@gmail.com (mailto) · PHONE +91 96547 36687 (tel:+919654736687) · LINKEDIN in/vaibhav252005 ↗ (https://linkedin.com/in/vaibhav252005) · GITHUB Vaibhav1962 ↗ (https://github.com/Vaibhav1962) · LEETCODE user3723OG ↗ (https://leetcode.com/u/user3723OG/)

---

## Interactions & Behavior

### Open transition (click hotspot or HUD nav)
1. `phase = 'zoom'`, `active = id`. Zoom wrapper gets `transform-origin: <ox>% <oy>%` and `transform: scale(2.8)`; filter `blur(1px) brightness(.85) saturate(1.25)`. Transition `transform 1000ms cubic-bezier(.75,0,.2,1), filter 900ms ease`. Accent flash layer → opacity .18 (220ms). HUD + hotspots fade out.
2. After **650ms** → `phase = 'open'`: filter becomes `blur(2px) brightness(.6) saturate(1.25)`; flash → 0; panel reveals: `clip-path inset(50% 0 50% 0) → inset(0 0 0 0)` (520ms cubic-bezier(.8,0,.2,1)), opacity 0→1 (200ms), `scale(.96) → scale(1)` (520ms same curve).
- Ignore clicks unless `phase === 'idle'`.

### Switch section (footer nav while open)
`swap = true` → body opacity 0 (180ms) + flash .18; after **180ms** set new `active`, `swap = false`. The zoom origin also updates, so the city re-aims behind the panel.

### Close (ESC key, close button, or backdrop click; only when `phase === 'open'`)
`phase = 'closing'`: panel collapses (reverse clip-path), scene scales back to 1, filter none. After **900ms** → `phase = 'idle'`, `active = null`.

### Mouse parallax
On `mousemove`: `dx = x/innerWidth - .5`, `dy = y/innerHeight - .5`; parallax wrapper `transform: scale(1.04) translate(${-dx*22}px, ${-dy*14}px)` with `transition: transform 900ms cubic-bezier(.2,.7,.2,1)`. Write to the DOM node directly (no re-render). The 1.04 base scale hides the edges.

### Ambient effects (canvas, drawn in image-space: `ctx.scale(canvasWidth/1448)`; DPR capped at 1.5; resize via ResizeObserver)
**Light detection (once, on image load):** draw the image to an offscreen canvas at 1/4 size (362×272). Luminance `L = .3R + .59G + .11B`.
- *City lights:* pixels with L ≥ 175 that are local maxima in their 3×3 neighborhood, excluding the hotspot label rectangles (+10px pad, +60px below for the leader lines). Sort by L, keep the top **420**. Per light: `size = 4 + (L-175)/80*9 + rand*3` (radius in image px), `phase = rand*2π`, `speed = .4 + rand*1.2`, `flicker = rand < .1`.
- *Stars:* random samples in the top 40% of the image where L ≤ 55 and blue ≤ 95 (dark sky only), up to **140**. Per star: `r = .5 + rand*1.1`, `phase`, `speed = .6 + rand*2`, `max = .25 + rand*.55`.

**Per frame:**
- Stars (source-over): `tw = .5 + .5*sin(t*speed + phase)`; alpha `max*tw²`; fill #dfe8ff circle. If `r > 1.3 && tw > .85`, draw a faint 4-point sparkle cross (half alpha, length r*6, width .6).
- Lights (`globalCompositeOperation='lighter'`): drawImage a cached 64×64 radial-gradient sprite tinted with the pixel's color (stops: 0 → color+60 brighten at alpha 1; .25 → color at .55; 1 → transparent; cache key = color quantized >>5) at `(x-size, y-size, 2*size)`. Alpha `= .12 + .3*(.5+.5*sin(t*speed+phase))`. Flicker lights hold alpha .45, and each frame have a .4% chance to go fully dark for 2–7 frames.
- Disable the whole loop under `prefers-reduced-motion: reduce`.

**Sign glows (CSS divs, `mix-blend-mode:screen`, `filter:blur(10px)`)** over specific signs. Each entry `[x, y, w, h, color, animation, duration s]` in image px. The div box is `left=(x-.6w)/1448, top=(y-.35h)/1086, width=2.2w/1448, height=1.7h/1086` (as %), background `radial-gradient(ellipse at center, <color>99 0%, <color>38 40%, transparent 70%)`, `animation: <anim> <dur>s ease-in-out <-(i*1.3)>s infinite`.
```
[1372,210,70,265,'#ff2d7a','flkA',5.3]  未来へ big sign
[700,605,55,110,'#ff2d7a','flkB',6.1]   進化
[312,230,40,115,'#ff3d6e','flkA',7.7]   夢を追え
[815,180,60,215,'#3fb8ff','breathe',4.2] fish billboard
[812,475,82,110,'#9a6bff','breathe',5.6] mountain billboard
[1238,500,104,148,'#2f7dff','flkB',9.4] CODE/BUILD panel
[1232,712,112,205,'#3a8bff','breathe',6.8] テクノロジー panel
[1035,425,28,130,'#e04bff','flkA',4.9]
[1145,335,32,75,'#ff3d8a','flkB',3.7]
[70,450,55,75,'#ff8a3a','breathe',3.1]   lantern
[795,705,50,120,'#ff6fa8','flkB',8.2]
[790,0,40,40,'#ff2d7a','flkA',6.6]
```
Keyframes:
```css
@keyframes flkA{0%,100%{opacity:.8}20%{opacity:.95}21%{opacity:.25}22%{opacity:.9}23%{opacity:.4}24%{opacity:.95}60%{opacity:.6}80%{opacity:1}}
@keyframes flkB{0%,100%{opacity:.55}45%{opacity:1}46%{opacity:.3}48%{opacity:.95}}
@keyframes breathe{0%,100%{opacity:.4}50%{opacity:1}}
@keyframes blink{50%{opacity:0}}
```

**Explicitly rejected by the client — do NOT add:** rain, flying-car light streaks, moving train, rooftop ripples, fog bands, glitch bars, scan sweep. The scanline overlay exists as an option but is **off** by default.

### Responsive
The image always covers the viewport, so on narrow or portrait screens some baked-in labels crop off-screen. The bottom-left HUD nav is the guaranteed way in. Panel is fluid (max 940px, 20px outer padding); content grids use `auto-fit, minmax(...)`.

### Accessibility
Hotspots are `<button>`s with `aria-label`. Add `role="dialog"`/`aria-modal`, focus trapping, and return focus to the trigger on close in production.

## State Management
- `active: null | 'about'|'projects'|'experience'|'skills'|'contact'`
- `phase: 'idle' | 'zoom' | 'open' | 'closing'` (timed transitions above)
- `swap: boolean` (section crossfade)
- Settings (in the prototype these were toggles; ship as constants): `zoomStrength = 2.8`, `scanlines = false`, `neonFlicker = true`, `parallax = true`.
- Optional: sync `active` to the URL hash (`#projects`) for deep links.

## Design Tokens
- Background #05060f · panel glass rgba(12,14,36,.62)→rgba(6,7,20,.8)
- Text: #ffffff (headings), #d9e2ff (UI), #c4cdf0 (body), #8b93b8 (muted)
- Accents: cyan #5ff3ff · pink #ff4fb8 (soft pink #ff8fd0) · amber #ffc46b
- Fonts (Google): **Chakra Petch** 500/600/700 (display), **JetBrains Mono** 400/500/700 (everything else)
- Radii: 3–4px (chips/buttons), 6px (cards/panel)
- Spacing used: 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 28px
- Selection: bg #ff4fb8, text #05060f
- Glow recipe: `box-shadow: 0 0 N <accent at ~33%>`, text `text-shadow: 0 0 N <accent at .4>`

## Assets
- `assets/city.png` — 1448×1086 cityscape supplied by the client, with the five labels baked in. All hotspot and glow coordinates depend on this exact image. If it's replaced, re-measure them. Consider exporting a WebP (~2.4 MB PNG now) for production.
- Icons: Lucide — user, box, briefcase, terminal, mail (stroke width 2).

## Files
- `reference/Portfolio.dc.html` — the full prototype (template markup with inline styles + the `Component` logic class at the bottom: hotspot data, transitions, canvas effects, sign glows).
- `reference/support.js` — prototype runtime only; not needed in production.
- `reference/uploads/…png` — the image at the path the prototype expects.
- `assets/city.png` — the same image for the real build.
