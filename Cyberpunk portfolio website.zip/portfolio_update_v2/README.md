# Portfolio — Update v2 (apply on top of the existing build)

You already built the cyberpunk portfolio from the first handoff. This package adds the changes made since then. **Do not rebuild from scratch.** Modify the existing codebase, and keep its framework, structure and conventions.

## What's inside
- `CHANGELOG.md`: the spec. It gives exact values for every change (timings, colours, sizes, positions).
- `reference/Portfolio.dc.html`: the working prototype with all changes applied. Open it in a browser (it needs `support.js` beside it) to see the intended behaviour. Treat it as a behaviour reference only. Its inline-style / DC structure is a prototyping format and should not be copied as-is.

## Changes to implement
1. **Random card glitch.** While a section panel is open, a random content card glitches with an RGB split, a jitter and a slice clip. The timing must be random with no fixed interval: next glitch after `700 + rand*rand*6500` ms, and a 25% chance of a second card glitching soon after. Use the Web Animations API (`el.animate`) with `steps(1,end)` hard cuts. Mark the targets (About info cards, Project + Research cards, Experience rows, Skill cards, Contact rows). Disable under `prefers-reduced-motion`.
2. **Neon name sign.** Replace the plain "VAIBHAV SINGH" text in the bottom-left HUD with a neon box sign: pink glowing tube frame, glowing name, and a katakana line "ヴァイバヴ・シン" in cyan. Keep the "BACKEND ENGINEER // NOIDA, IN" line below it. The "G" flickers at random: a burst of hard cuts every 1.5–8.5 s, and sometimes it stays dim for 1–3 s.
3. **Neon HUD buttons.** The bottom section buttons become always-lit neon tubes in their section colour (border, outer and inset glow, glowing text and icon). The glow intensifies on hover.
4. **Neon cursors.** Custom SVG cursors with a glow: a cyan arrow by default, and a magenta corner-bracket reticle with a centre dot over anything clickable (`a`, `button`, `[role=button]`). Use CSS `cursor: url(data:image/svg+xml…) x y, fallback`. The SVG markup is in `reference/Portfolio.dc.html` → `applyCursor()`.

Item 1 and item 4 should each have a config flag (on by default), matching how the existing effect toggles work in the codebase.

## Tried and rejected: do NOT build
- Name sign floating in the sky (it was moved to the HUD instead).
- Boot-up intro / loading screen.
- Neon car/bike moving along the road under the train.
- Scanlines are off in the current preferred look. If the existing build has them, default them to off.

## Unchanged
Everything else from the original handoff (city image, light canvas, sign glows, stars, zoom transition, panel design, section content, mobile menu, parallax) stays as it is.

## Acceptance check
- Open a section: within a few seconds, cards glitch at irregular times, never on a fixed beat.
- The bottom-left shows the neon sign, and the G flickers on its own.
- The HUD buttons glow at rest and glow brighter on hover.
- The cursor is a cyan arrow and switches to the magenta reticle on every clickable element, including inside panels.
- No console errors. With reduced motion on, the glitches and flicker stop.
