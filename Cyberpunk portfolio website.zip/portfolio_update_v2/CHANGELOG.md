# Changelog — changes after the original Claude Code build

Reference implementation: `Portfolio.dc.html` (project root). Each item has an Effects toggle in Tweaks.

## 2026-10-06

### 1. Random card glitch (`glitchCards`)
- Only while a section panel is open. Targets every element marked `data-glitch` (About info cards, Project + Research cards, Experience rows, Skill cards, Contact rows).
- Scheduling is random, not interval: next glitch after `700 + rand*rand*6500` ms (skews toward short gaps with occasional long pauses). 25% chance of a second card glitching 60–200 ms later.
- Each glitch: Web Animations API, 140–400 ms, 2–6 random hard-cut frames (`steps(1,end)`): translate ±7px x / ±1.5px y, 60% chance of a horizontal `clip-path: inset()` slice, RGB split via `drop-shadow(±1–5px 0 0 #ff4fb8 / #5ff3ff @ .85)`. Starts/ends clean.
- Skipped for `prefers-reduced-motion`.

### 2. Neon name sign (replaces the plain HUD name, bottom-left)
- The sky-sign trial was dropped; the same neon box sign now replaces the "VAIBHAV SINGH" text above "BACKEND ENGINEER // NOIDA, IN". No toggle.
- Box: font-size clamp(20px,2.6vw,34px), padding .45em .7em .5em, border .08em rgba(255,150,215,.85), radius .35em, bg rgba(10,4,18,.45), glow `0 0 .4em rgba(255,79,184,.8), inset 0 0 .4em rgba(255,79,184,.45)`.
- Name: Chakra Petch 700, letter-spacing .14em, #ffe9f6, text-shadow `0 0 .08em #fff, 0 0 .25em #ff4fb8, 0 0 .6em #ff4fb8, 0 0 1.2em rgba(255,45,122,.7)`. Katakana line "ヴァイバヴ・シン" .42em, .5em tracking, #e2fcff with cyan glow.
- The "G" flickers at random: every 1.5–8.5 s a 250–950 ms burst of hard on/off cuts; 15% chance it then stays dim for 1.2–2.7 s.

### 2b. Neon HUD buttons (bottom nav)
- Always-lit tube look: 1.5px border in section colour, radius 6px, white text, text-shadow `0 0 8px <color>99`, box-shadow `0 0 8px <color>99, inset 0 0 6px <color>99`, icon `drop-shadow(0 0 3px <color>)`.
- Hover: bg rgba(255,255,255,.08), glow to full colour (`0 0 16px`, inset `10px`).

### 3. ~~Boot intro~~ — REMOVED (tried, rejected). Do not build.

### 4. Neon cursors (`neonCursor`)
- CSS cursors from inline SVG data URIs (32×32, Gaussian glow filter), applied via `html[data-neon-cursor]`.
- Default: cyan (#5ff3ff) outlined arrow, dark fill, hotspot 6 4.
- Clickable (a, button, [role=button]): magenta (#ff4fb8) corner-bracket reticle with center dot, hotspot 16 16.

### 5. ~~Neon vehicle on the road under the train~~ — REMOVED (tried, rejected). Do not build.
